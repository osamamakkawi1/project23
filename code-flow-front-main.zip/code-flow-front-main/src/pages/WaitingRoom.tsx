
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const WaitingRoom = () => {
  const { courtId } = useParams<{ courtId: string }>();
  const [queuePosition, setQueuePosition] = useState<number | null>(null);
  const [waitTime, setWaitTime] = useState<number | null>(null);

  const courtNames: Record<string, string> = {
    main: "Dubai Courts Main Building",
    personal: "Personal Status & Inheritance Court",
    labour: "Labour Court & Execution Court",
    rashidiya: "Al Adheed Al Rashidya",
  };

  // Simulate fetching the queue position and wait time
  useEffect(() => {
    // In a real app, this would be an API call
    const randomPosition = Math.floor(Math.random() * 5) + 1;
    const randomWaitTime = randomPosition * 5;
    setQueuePosition(randomPosition);
    setWaitTime(randomWaitTime);
  }, [courtId]);

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
        <Card className="w-full max-w-md shadow-lg">
          <CardContent className="pt-6 text-center">
            <div className="flex justify-center mb-6">
              <div className="bg-court-100 p-4 rounded-full">
                <div className="text-court-500 text-4xl">👤</div>
              </div>
            </div>

            <h1 className="text-2xl font-bold mb-2">You are in the waiting room</h1>
            <p className="text-gray-600 mb-6">{courtNames[courtId as string] || "Dubai Courts"}</p>

            <div className="space-y-6">
              <div className="bg-gray-50 p-4 rounded-lg flex justify-between items-center">
                <div className="flex items-center text-gray-700">
                  <span className="mr-2">👥</span>
                  <span>Your position in queue:</span>
                </div>
                <span className="font-bold text-lg">{queuePosition}</span>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg flex justify-between items-center">
                <div className="flex items-center text-gray-700">
                  <span className="mr-2">⏱️</span>
                  <span>Estimated wait time:</span>
                </div>
                <span className="font-bold text-lg">{waitTime} minutes</span>
              </div>

              <Button className="w-full bg-court-400 hover:bg-court-500 flex items-center justify-center">
                <span className="mr-2">▶️</span>
                Watch Welcome Video
              </Button>

              <p className="text-sm text-gray-500 mt-6">
                Please stay on this page. You will be notified when it is your turn.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default WaitingRoom;
