
import { useState } from "react";
import Layout from "@/components/layout/Layout";
import { TabNavigation } from "@/components/Dashboard/TabNavigation";
import ClientStatusCard from "@/components/Dashboard/ClientStatusCard";
import ClientList from "@/components/Dashboard/ClientList";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const AdminClients = () => {
  const [user] = useState({
    name: "Sara Al-Khalil",
  });

  const handleLogout = () => {
    // In a real app, handle logout
    console.log("Logout clicked");
  };

  // Mock data for clients
  const clients = [
    {
      id: "1",
      name: "John Smith",
      phone: "+971501234567",
      courtroom: "Dubai Courts Main",
      entryTime: "Jan 15, 2025, 01:30 PM",
      status: "Waiting" as const,
    },
    {
      id: "2",
      name: "Aisha Mohamed",
      phone: "+971502345678",
      courtroom: "Personal Status",
      entryTime: "Jan 15, 2025, 02:15 PM",
      status: "Waiting" as const,
    },
    {
      id: "3",
      name: "Robert Chen",
      phone: "+971503456789",
      courtroom: "Labour Court",
      entryTime: "Jan 15, 2025, 03:00 PM",
      status: "In Meeting" as const,
    },
    {
      id: "4",
      name: "Layla Khan",
      phone: "+971504567890",
      courtroom: "Al Adheed",
      entryTime: "Jan 15, 2025, 03:45 PM",
      status: "Completed" as const,
    },
  ];

  // Filter clients by status
  const waitingClients = clients.filter(client => client.status === "Waiting");
  const inMeetingClients = clients.filter(client => client.status === "In Meeting");
  const completedClients = clients.filter(client => client.status === "Completed");

  // State for active filter
  const [activeFilter, setActiveFilter] = useState("All");

  // Filtered clients based on active filter
  const getFilteredClients = () => {
    switch (activeFilter) {
      case "Waiting":
        return waitingClients;
      case "In Meeting":
        return inMeetingClients;
      case "Completed":
        return completedClients;
      default:
        return clients;
    }
  };

  return (
    <Layout user={user} onLogout={handleLogout}>
      <div className="bg-gray-50 min-h-screen">
        <div className="container mx-auto px-4 py-6">
          <div className="mb-6">
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-gray-600">Hello, Sara Al-Khalil. Here's an overview of court activity.</p>
          </div>

          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <ClientStatusCard
              status="Total Clients"
              count={4}
              icon={<span className="text-2xl">👥</span>}
            />
            <ClientStatusCard
              status="Total Meetings"
              count={2}
              icon={<span className="text-2xl">🗓️</span>}
            />
            <ClientStatusCard
              status="Total Agents"
              count={3}
              icon={<span className="text-2xl">👤</span>}
            />
            <ClientStatusCard
              status="Average Rating"
              count={5.0}
              icon={<span className="text-2xl">⭐</span>}
            />
          </div>

          {/* Tabs */}
          <div className="bg-white rounded-lg shadow overflow-hidden mb-8">
            <TabNavigation activeTab="clients" />
            
            <div className="p-6">
              {/* Search Bar */}
              <div className="mb-6">
                <Input 
                  placeholder="Search clients..." 
                  className="max-w-sm" 
                />
              </div>

              {/* Status Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
                <ClientStatusCard
                  status="Waiting"
                  count={waitingClients.length}
                  icon={<span className="text-2xl">⏳</span>}
                  className="bg-amber-50"
                />
                <ClientStatusCard
                  status="In Meeting"
                  count={inMeetingClients.length}
                  icon={<span className="text-2xl">👥</span>}
                  className="bg-blue-50"
                />
                <ClientStatusCard
                  status="Completed"
                  count={completedClients.length}
                  icon={<span className="text-2xl">✅</span>}
                  className="bg-green-50"
                />
              </div>

              {/* Client List */}
              <div className="mb-4">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-semibold">Client List</h2>
                  <div className="flex gap-2">
                    <Button 
                      variant={activeFilter === "All" ? "default" : "outline"} 
                      size="sm"
                      onClick={() => setActiveFilter("All")}
                      className={activeFilter === "All" ? "bg-red-600" : ""}
                    >
                      All
                    </Button>
                    <Button 
                      variant={activeFilter === "Waiting" ? "default" : "outline"} 
                      size="sm"
                      onClick={() => setActiveFilter("Waiting")}
                    >
                      Waiting
                    </Button>
                    <Button 
                      variant={activeFilter === "In Meeting" ? "default" : "outline"} 
                      size="sm"
                      onClick={() => setActiveFilter("In Meeting")}
                    >
                      In Meeting
                    </Button>
                    <Button 
                      variant={activeFilter === "Completed" ? "default" : "outline"} 
                      size="sm"
                      onClick={() => setActiveFilter("Completed")}
                    >
                      Completed
                    </Button>
                  </div>
                </div>

                <ClientList clients={getFilteredClients()} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default AdminClients;
