
import { useState } from "react";
import Layout from "@/components/layout/Layout";
import { TabNavigation } from "@/components/Dashboard/TabNavigation";
import StatCard from "@/components/Dashboard/StatCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend, 
  PieChart, 
  Pie, 
  Cell,
  LineChart,
  Line 
} from "recharts";

// Mock data for charts
const clientActivityData = [
  { date: "Jan 10", clients: 42, meetings: 38 },
  { date: "Jan 11", clients: 35, meetings: 32 },
  { date: "Jan 12", clients: 28, meetings: 25 },
  { date: "Jan 13", clients: 45, meetings: 39 },
  { date: "Jan 14", clients: 52, meetings: 48 },
  { date: "Jan 15", clients: 38, meetings: 35 },
];

const courtroomDistribution = [
  { name: "Dubai Courts Main Building", value: 84 },
  { name: "Personal Status & Inheritance Court", value: 45 },
  { name: "Labour Court & Execution Court", value: 62 },
  { name: "Al Adheed Al Rashidya", value: 53 },
];

const agentPerformance = [
  { name: "Ahmed Hassan", meetings: 85, rating: 4.7 },
  { name: "Fatima Al-Mansouri", meetings: 92, rating: 4.8 },
  { name: "Mohammed Al-Maktoum", meetings: 65, rating: 4.6 },
];

const COLORS = ["#d32f2f", "#7b1fa2", "#1976d2", "#ff9800", "#000000"];

const AdminAnalytics = () => {
  const [user] = useState({
    name: "Sara Al-Khalil",
  });

  const handleLogout = () => {
    // In a real app, handle logout
    console.log("Logout clicked");
  };

  return (
    <Layout user={user} onLogout={handleLogout}>
      <div className="bg-gray-50 min-h-screen">
        <div className="container mx-auto px-4 py-6">
          <div className="mb-6">
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-gray-600">Hello, Sara Al-Khalil. Here's an overview of court activity.</p>
          </div>

          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <StatCard
              title="Total Clients"
              value="4"
              icon={<span className="text-2xl">👥</span>}
            />
            <StatCard
              title="Total Meetings"
              value="2"
              icon={<span className="text-2xl">🗓️</span>}
            />
            <StatCard
              title="Total Agents"
              value="3"
              icon={<span className="text-2xl">👤</span>}
            />
            <StatCard
              title="Average Rating"
              value="5.0"
              icon={<span className="text-2xl">⭐</span>}
            />
          </div>

          {/* Tabs */}
          <div className="bg-white rounded-lg shadow overflow-hidden mb-8">
            <TabNavigation activeTab="analytics" />
            
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold">System Analytics</h2>
                <Button variant="outline" className="flex items-center space-x-2">
                  <span>Export Report</span>
                </Button>
              </div>

              {/* Key Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">Today's Clients</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="text-3xl font-bold">42</h3>
                        <p className="text-xs text-gray-500">Total clients today</p>
                      </div>
                      <div className="text-green-500 text-sm font-medium">
                        +12.5%
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">Average Rating</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="text-3xl font-bold">4.7</h3>
                        <p className="text-xs text-gray-500">Out of 5 stars</p>
                      </div>
                      <div className="text-green-500 text-sm font-medium">
                        +3.2%
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">Average Wait Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="text-3xl font-bold">14.2</h3>
                        <p className="text-xs text-gray-500">Minutes</p>
                      </div>
                      <div className="text-green-500 text-sm font-medium">
                        -8.7%
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                {/* Client Activity Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle>Client Activity</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={clientActivityData}>
                          <XAxis dataKey="date" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="clients" fill="#d32f2f" name="Clients" />
                          <Bar dataKey="meetings" fill="#607d8b" name="Meetings" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                {/* Courtroom Distribution Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle>Courtroom Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={courtroomDistribution}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            innerRadius={40}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          >
                            {courtroomDistribution.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Agent Performance */}
              <Card>
                <CardHeader>
                  <CardTitle>Agent Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart 
                        data={agentPerformance}
                        layout="vertical"
                        margin={{ top: 20, right: 30, left: 100, bottom: 5 }}
                      >
                        <XAxis type="number" />
                        <YAxis dataKey="name" type="category" />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="meetings" name="Meetings" fill="#d32f2f" />
                        <Line 
                          type="monotone" 
                          dataKey="rating" 
                          name="Rating" 
                          stroke="#1976d2" 
                          strokeWidth={2} 
                          yAxisId={1} 
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default AdminAnalytics;
