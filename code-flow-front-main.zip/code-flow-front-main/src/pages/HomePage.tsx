
import Layout from "@/components/layout/Layout";
import CourtroomCard from "@/components/CourtroomCard";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

const HomePage = () => {
  const navigate = useNavigate();
  
  const courtrooms = [
    {
      id: "main",
      title: "Dubai Courts Main Building",
      description: "Main courthouse handling general cases",
      icon: "🏢",
    },
    {
      id: "personal",
      title: "Personal Status & Inheritance Court",
      description: "Handling family law and inheritance cases",
      icon: "⚖️",
    },
    {
      id: "labour",
      title: "Labour Court & Execution Court",
      description: "Handling employment disputes and execution of judgments",
      icon: "💼",
    },
    {
      id: "rashidiya",
      title: "Al Adheed Al Rashidya",
      description: "Branch court serving the Al Rashidya area",
      icon: "🏠",
    },
  ];

  return (
    <Layout>
      <div className="bg-gradient-to-b from-gray-50 to-white py-12">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">Welcome to Dubai Courts Virtual Meeting Platform</h1>
            <p className="text-gray-600 mb-6">Please select a courtroom:</p>
            <Button 
              variant="outline" 
              className="bg-white"
              onClick={() => navigate("/welcome-video")}
            >
              <span className="mr-2">▶️</span>
              Watch Welcome Video
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {courtrooms.map((courtroom) => (
              <CourtroomCard
                key={courtroom.id}
                id={courtroom.id}
                title={courtroom.title}
                description={courtroom.description}
                icon={courtroom.icon}
              />
            ))}
          </div>

          <div className="mt-20">
            <h2 className="text-2xl font-bold text-center mb-12">Important Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
                <h3 className="text-xl font-semibold text-court-600 mb-4">Easy Access</h3>
                <p className="text-gray-700">
                  Select your needed court and register your information to enter the virtual waiting room.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
                <h3 className="text-xl font-semibold text-court-600 mb-4">Virtual Meetings</h3>
                <p className="text-gray-700">
                  When it's your turn, you will be admitted to a Zoom room to meet with one of our agents.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
                <h3 className="text-xl font-semibold text-court-600 mb-4">Feedback & Rating</h3>
                <p className="text-gray-700">
                  After the meeting, you will have the opportunity to rate our service and provide feedback.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default HomePage;
