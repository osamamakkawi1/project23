
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password) {
      setError("Please enter both email and password");
      return;
    }
    
    // Demo login logic - in real app, this would call an API
    if (email === "sara@dubaicourts.ae" && password === "password") {
      // Admin login
      toast.success("Login successful. Welcome to the admin dashboard!");
      navigate("/admin/analytics");
    } else if (
      ["ahmed@dubaicourts.ae", "fatima@dubaicourts.ae", "mohammed@dubaicourts.ae"].includes(email) && 
      password === "password"
    ) {
      // Agent login
      toast.success("Login successful. Welcome!");
      navigate("/admin/clients");
    } else {
      setError("Invalid credentials. Please try again.");
    }
  };

  return (
    <Layout hideFooter>
      <div className="flex min-h-[calc(100vh-4rem)] bg-gray-50">
        <div className="flex flex-1 flex-col justify-center py-12 px-4 sm:px-6 lg:flex-none lg:px-20 xl:px-24">
          <div className="mx-auto w-full max-w-sm lg:w-96">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold tracking-tight text-gray-900">Login</h2>
              <p className="mt-2 text-sm text-gray-600">
                Sign in to access your dashboard
              </p>
            </div>

            <form className="space-y-6" onSubmit={handleSubmit}>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                  Email
                </label>
                <div className="mt-1">
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                  Password
                </label>
                <div className="mt-1">
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
              </div>

              {error && (
                <div className="text-sm text-red-500">
                  {error}
                </div>
              )}

              <div>
                <Button type="submit" className="w-full bg-court-400 hover:bg-court-500">
                  Login
                </Button>
              </div>
            </form>

            <div className="mt-10">
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-gray-50 text-gray-500">Demo Accounts</span>
                </div>
              </div>

              <div className="mt-6">
                <p className="text-sm text-center text-gray-600">
                  Use any of the following emails with any password:
                </p>
                <ul className="mt-4 text-sm list-disc pl-5 space-y-1 text-gray-600">
                  <li>ahmed@dubaicourts.ae (Agent)</li>
                  <li>fatima@dubaicourts.ae (Agent)</li>
                  <li>mohammed@dubaicourts.ae (Agent)</li>
                  <li>sara@dubaicourts.ae (Admin)</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="hidden lg:block relative w-0 flex-1 bg-court-400">
          <div className="absolute inset-0 flex items-center justify-center text-white text-8xl font-bold">
            DC
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Login;
