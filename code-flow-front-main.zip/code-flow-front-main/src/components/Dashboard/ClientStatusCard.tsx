
import { ReactNode } from "react";
import { Card, CardContent } from "@/components/ui/card";

interface ClientStatusCardProps {
  status: string;
  count: number;
  icon: ReactNode;
  className?: string;
}

const ClientStatusCard = ({ status, count, icon, className = "" }: ClientStatusCardProps) => {
  let bgColor = "";
  
  switch(status.toLowerCase()) {
    case "waiting":
      bgColor = "bg-amber-50";
      break;
    case "in meeting":
      bgColor = "bg-blue-50";
      break;
    case "completed":
      bgColor = "bg-green-50";
      break;
    default:
      bgColor = "bg-gray-50";
  }

  return (
    <Card className={`${className} ${bgColor}`}>
      <CardContent className="pt-6">
        <div className="flex items-center">
          <div className="mr-4">{icon}</div>
          <div>
            <p className="text-sm text-muted-foreground">{status}</p>
            <h3 className="text-2xl font-bold tracking-tight">{count}</h3>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ClientStatusCard;
