
import { Link } from "react-router-dom";

interface TabNavigationProps {
  activeTab: string;
}

export const TabNavigation = ({ activeTab }: TabNavigationProps) => {
  const tabs = [
    { name: "Analytics", path: "/admin/analytics" },
    { name: "Clients", path: "/admin/clients" },
    { name: "Agents", path: "/admin/agents" },
    { name: "Feedback", path: "/admin/feedback" },
    { name: "Settings", path: "/admin/settings" },
  ];

  return (
    <div className="flex overflow-x-auto">
      {tabs.map((tab) => (
        <Link
          key={tab.name}
          to={tab.path}
          className={`px-4 py-2 text-sm font-medium whitespace-nowrap ${
            activeTab === tab.name.toLowerCase()
              ? "text-court-500 border-b-2 border-court-500"
              : "text-gray-600 hover:text-court-500"
          }`}
        >
          {tab.name}
        </Link>
      ))}
    </div>
  );
};
