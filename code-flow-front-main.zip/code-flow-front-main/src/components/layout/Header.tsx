
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

interface HeaderProps {
  user?: {
    name: string;
  };
  onLogout?: () => void;
}

export function Header({ user, onLogout }: HeaderProps) {
  return (
    <header className="bg-white border-b border-gray-200">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="bg-court-400 text-white font-bold w-8 h-8 rounded flex items-center justify-center">
            DC
          </div>
          <h1 className="text-xl font-semibold">Dubai Courts</h1>
        </div>

        <div className="flex items-center space-x-4">
          <div className="hidden md:flex">
            <Button variant="ghost" size="sm" asChild>
              <Link to="/" className="flex items-center">
                <span className="mr-1">🌐</span>
                English
              </Link>
            </Button>
          </div>

          {user ? (
            <div className="flex items-center space-x-4">
              <div className="hidden md:block">
                <span className="text-sm font-medium">{user.name}</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-600 hover:text-gray-900"
                onClick={onLogout}
                asChild
              >
                <Link to="/login">Logout</Link>
              </Button>
            </div>
          ) : (
            <Button variant="ghost" size="sm" asChild>
              <Link to="/login">Login</Link>
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
