
import { PropsWithChildren } from "react";
import { Header } from "./Header";
import Footer from "./Footer";

interface LayoutProps {
  user?: {
    name: string;
  };
  hideFooter?: boolean;
  onLogout?: () => void;
}

const Layout = ({ 
  children, 
  user, 
  hideFooter = false,
  onLogout 
}: PropsWithChildren<LayoutProps>) => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header user={user} onLogout={onLogout} />
      <main className="flex-grow">
        {children}
      </main>
      {!hideFooter && <Footer />}
    </div>
  );
};

export default Layout;
