
const Footer = () => {
  return (
    <footer className="bg-gray-900 text-gray-300 py-8 mt-auto">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="flex flex-col">
            <div className="flex items-center space-x-2 mb-4">
              <div className="bg-court-400 text-white font-bold w-8 h-8 rounded flex items-center justify-center">
                DC
              </div>
              <h3 className="text-xl font-semibold text-white">Dubai Courts</h3>
            </div>
            <p className="text-sm">© 2025 Dubai Courts. All rights reserved.</p>
          </div>
          
          <div>
            <h4 className="text-lg font-medium mb-4 text-white">Contact</h4>
            <ul className="space-y-2 text-sm">
              <li>+971 4 353 3337</li>
              <li>info@dc.gov.ae</li>
              <li>Dubai, United Arab Emirates</li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-medium mb-4 text-white">Links</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="/" className="hover:text-court-400 transition-colors">Home</a></li>
              <li><a href="#" className="hover:text-court-400 transition-colors">Support</a></li>
              <li><a href="#" className="hover:text-court-400 transition-colors">Terms & Conditions</a></li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
