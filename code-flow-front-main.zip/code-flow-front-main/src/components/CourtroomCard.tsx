
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ReactNode } from "react";

interface CourtroomCardProps {
  title: string;
  description: string;
  icon: ReactNode;
  id: string;
}

const CourtroomCard = ({ title, description, icon, id }: CourtroomCardProps) => {
  return (
    <Card className="overflow-hidden transition-shadow duration-300 hover:shadow-lg">
      <div className="bg-gradient-to-r from-court-600 to-court-400 p-6 flex justify-center">
        <div className="text-white text-4xl">{icon}</div>
      </div>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription className="text-gray-600 mt-2">{description}</CardDescription>
      </CardHeader>
      <CardFooter className="pt-0">
        <Button asChild variant="link" className="text-court-500 p-0 hover:text-court-600">
          <Link to={`/register/${id}`}>
            Click to register 
          </Link>
        </Button>
      </CardFooter>
    </Card>
  );
};

export default CourtroomCard;
